export PATH=/opt/xilinx/bin:${PATH}:/usr/local/sbin:/usr/sbin:/sbin
